
# Ejercicio 2. Identiificacion de tipos de datos.

nombre = "pedro"
edad = 19
estatura = 1.75
matriculado = True

print(type(nombre))
print(type(edad))
print(type(estatura))
print(type(matriculado))